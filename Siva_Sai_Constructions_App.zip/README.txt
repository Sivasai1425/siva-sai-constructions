SIVA SAI CONSTRUCTIONS APP
Open index.html in a web browser.

To install on Android:
1. Host these files on any HTTPS web hosting service.
2. Open the hosted address in Chrome.
3. Chrome menu ⋮ -> Add to Home screen / Install app.
4. Choose Siva Sai Constructions.

The calculator rates are starter values and should be replaced with your actual rates.
